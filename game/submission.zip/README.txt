I) Citations:

	1) Lesson 4 from Learning webGL has been used to start with the project. Since learning webgl has been used as the base code, it was cited as a whole rather than citing individual functions. The links are as follows:
			a) http://learningwebgl.com/blog/?p=370 
			b) https://github.com/gpjt/webgl-lessons/blob/master/lesson04/index.html (Used this code at different places in my program to render white triangles) 

	2) Adding sound:
		http://stackoverflow.com/questions/1933969/sound-effects-in-javascript-html5

	3) Key press:
		https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent


II) How to execute:

	Unzip the submission.zip. Run the file index.html
	

III) Notes:

	1) As a part of the extra credit, sound, score have been implemented.
	2) Pink cube is the player, remaining cubes are enemies

IV) Link to ScreenCast: https://www.youtube.com/watch?v=fKo2eRsDHX8

	